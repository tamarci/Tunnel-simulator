//
// Created by Marci on 2020. 04. 24..
//

#ifndef NAGYHAZI2_ENUMS_H
#define NAGYHAZI2_ENUMS_H

//#include "memtrace.h"
enum Allapot {
    Init, All1, All2, All3, All4
};

enum Szin {
    zold, piros
};

#endif //NAGYHAZI2_ENUMS_H
